package com.profesor.loteria;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class MainController implements Initializable {
    private final String FICHERO_SONIDO = "music/wrong.mp3";

    @FXML
    private Button generarBoleto;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        generarBoleto.setDisable(true); // Deshabilitar el botón inicialmente

        inputBoleto.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                inputBoleto.setText(newValue.replaceAll("[^\\d]", ""));
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error de entrada");
                alert.setHeaderText(null);
                alert.setContentText("No se permite escribir letras.");
                alert.showAndWait();
            }
            if (inputBoleto.getText().length() > 5) {
                inputBoleto.setText(inputBoleto.getText().substring(0, 5));
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error de entrada");
                alert.setHeaderText(null);
                alert.setContentText("No se puede escribir más de 5 números.");
                alert.showAndWait();
            }
            generarBoleto.setDisable(inputBoleto.getText().length() != 5); // Habilitar o deshabilitar el botón
        });
    }

    @FXML
    private TextField inputBoleto;


    public void handlerGenerarBoleto(ActionEvent actionEvent) {

    }

    @FXML
    private void handlerCerrarAplicacion(ActionEvent event) {
        Platform.exit();
    }
}